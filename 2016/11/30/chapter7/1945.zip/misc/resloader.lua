res = {}
res.spritesheet = lg.newImage(path.."res/1945.png")
res.g64 = anim8.newGrid(64,64, 1024,768,  299,101,   2)
res.gBoom = anim8.newGrid(64,64, 1024,768, 2.5,300,   2)
